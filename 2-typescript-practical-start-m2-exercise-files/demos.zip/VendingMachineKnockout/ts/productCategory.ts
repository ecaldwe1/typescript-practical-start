class SodaCategory {
    name = "Soda"
    getImageUrl () {
        return "img/SodaCan.png"
    }
}